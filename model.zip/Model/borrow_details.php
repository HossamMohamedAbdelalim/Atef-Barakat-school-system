<?php
include_once("My DB.php");
include_once("book.php");
include_once("categoriestype.php");
include_once("duration.php");
class borrow_details
{
    public $id;
    public $bookObj;
    public $categoriestypeObj;  
    public $durationObj;
    public $created;
   

    
    function __construct($id)
    {
        $stmt = DatabaseConnection::getInstance()->database_connection-> prepare();
            
        if($id !="")
        {
            $sql="select * from   borrow_details  where id = $id";
            $borrow_detailsDataSet = mysqli_query($sql)  or die (mysqli_error());
            if($row = mysqli_fetch_array($borrow_detailsDataSet))
            {
                $this->id = $id;
              $this->bookObj = new book();
              $this->categoriestypeObj= new categoriestype();
              $this->durationObj= new duration();
              $this->created= $row ["created"];
            }

        }

    }

    public function creat()
    {
       if(isset($_POST['submit'])) {
        $id = $_POST['id'];
        $created =  $_POST['created'];
       }

       $sql = "INSERT INTO  borrow_details  ('created ') VALUES ('$created ')  ";
        
       $result = DatabaseConnection::getInstance()->database_connection->query($sql);

       if($result == TRUE)
       {
           echo "New record created succesfully";

       }

       else {
           echo "Error:" .$sql . "<br>". DatabaseConnection::getInstance()->database_connection->error;
       }


    }

   

    public function update()
    {
       if(isset($_POST['update'])) {
        $id = $_POST['id'];
        $created =  $_POST['created'];
       }

       $sql = "UPDATE  borrow_details SET 'id' = $id,'created' = created ";
        
       $result = DatabaseConnection::getInstance()->database_connection->query($sql);

       if($result == TRUE)
       {
           echo "New record Updated succesfully";

       }

       else {
           echo "Error:" .$sql . "<br>". DatabaseConnection::getInstance()->database_connection->error;
       }


    }


    public function delete()
    {
       if(isset($_GET['id'])) {
       $borrow_details_id = $_GET['id'];
       
       }

       $sql = "DELETE  FROM  borrow_details  WHERE 'id' = '$borrow_details_id'";
        
       $result = DatabaseConnection::getInstance()->database_connection->query($sql);

       if($result == TRUE)
       {
           echo " Record deleted succesfully";

       }

       else {
           echo "Error:" .$sql . "<br>". DatabaseConnection::getInstance()->database_connection->error;
       }


    }

   

   
           
}

?>


